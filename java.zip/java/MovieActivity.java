package com.example.filmme;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;

public class MovieActivity extends AppCompatActivity {

    ImageView imgMovieBig, imgMovie;
    TextView title, duration, genre, description;
    String userid,movieid,userphone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie);

        imgMovie = findViewById(R.id.movieImageView);
        imgMovieBig = findViewById(R.id.imageView4);
        title = findViewById(R.id.titleTextView);
        duration = findViewById(R.id.durationTextView);
        genre = findViewById(R.id.genreTextView);
        description = findViewById(R.id.descriptionTextView);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        movieid = bundle.getString("movieid");
        String rtitle = bundle.getString("title");
        String rduration = bundle.getString("duration");
        String rgenre = bundle.getString("genre");
        String rdescription = bundle.getString("description");

        userid = bundle.getString("userid");
        userphone = bundle.getString("userphone");

        title.setText(rtitle);
        duration.setText(rduration);
        genre.setText(rgenre);
        description.setText(rdescription);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorPrimaryDark)));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Picasso.get().load("http://funsproject.com/fahriProject/imageUpload/movieBig/"+movieid+".jpg")
                .fit().into(imgMovieBig);
        Picasso.get().load("http://funsproject.com/fahriProject/imageUpload/movieCover/"+movieid+".jpg")
                .fit().into(imgMovie);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(MovieActivity.this,MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("userid",userid);
                bundle.putString("phone",userphone);
                intent.putExtras(bundle);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                startActivity(intent);
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
