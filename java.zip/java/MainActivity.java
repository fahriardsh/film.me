package com.example.filmme;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    ListView lvmovie;
    Spinner spgenre;
    String userid,name,phone;
    ArrayList<HashMap<String, String>> movielist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvmovie = findViewById(R.id.listviewMovie);
        spgenre = findViewById(R.id.spinnerGenre);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        userid = bundle.getString("userid");
        name = bundle.getString("name");
        phone = bundle.getString("phone");
        loadMovie(spgenre.getSelectedItem().toString());

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.colorPrimaryDark)));

        lvmovie.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(MainActivity.this, restlist.get(position).get("restid"), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this,MovieActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("movieid",movielist.get(position).get("movieid"));
                bundle.putString("title",movielist.get(position).get("title"));
                bundle.putString("duration",movielist.get(position).get("duration"));
                bundle.putString("genre",movielist.get(position).get("genre"));
                bundle.putString("description",movielist.get(position).get("description"));

                bundle.putString("userid",userid);
                bundle.putString("userphone",phone);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        spgenre.setSelection(0,false);
        spgenre.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadMovie(spgenre.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
    private void loadMovie(final String genre) {
        class LoadMovie extends AsyncTask<Void,Void,String>{

            @Override
            protected String doInBackground(Void... voids) {
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("genre",genre);
                RequestHandler rh = new RequestHandler();
                movielist = new ArrayList<>();
                String s = rh.sendPostRequest
                        ("http://funsproject.com/fahriProject/load_movie.php",hashMap);
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                movielist.clear();
                try{
                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray moviearray = jsonObject.getJSONArray("movie");
                    for (int i=0;i<moviearray.length();i++){
                        JSONObject c = moviearray.getJSONObject(i);
                        String mid = c.getString("movieid");
                        String rtitle = c.getString("title");
                        String rduration = c.getString("duration");
                        String rgenre = c.getString("genre");
                        String rdescription = c.getString("description");

                        HashMap<String,String> movielisthash = new HashMap<>();
                        movielisthash.put("movieid",mid);
                        movielisthash.put("title",rtitle);
                        movielisthash.put("duration",rduration);
                        movielisthash.put("genre",rgenre);
                        movielisthash.put("description",rdescription);
                        movielist.add(movielisthash);
                    }
                }catch (final JSONException e){
                    Log.e("JSONERROR",e.toString());
                }

                ListAdapter adapter = new CustomAdapter(
                        MainActivity.this, movielist,
                        R.layout.list_movie, new String[]
                        {"title","duration","genre"}, new int[]
                        {R.id.titleTextView,R.id.durationTextView,R.id.genreTextView});
                lvmovie.setAdapter(adapter);
            }

        }
        LoadMovie loadMovie = new LoadMovie();
        loadMovie.execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.logo:
                Intent intent1 = new Intent(MainActivity.this,AboutActivity.class);
                startActivity(intent1);
                return true;
            case R.id.myprofile:
                Intent intent = new Intent(MainActivity.this,ProfileActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("userid",userid);
                bundle.putString("username",name);
                bundle.putString("phone",phone);
                intent.putExtras(bundle);
                startActivity(intent);
                return true;
            case R.id.logout:
                Intent intent2 = new Intent(MainActivity.this,LoginActivity.class);
                Toast.makeText(MainActivity.this, "Logout Success",
                        Toast.LENGTH_SHORT).show();
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
