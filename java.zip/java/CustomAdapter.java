package com.example.filmme;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomAdapter extends SimpleAdapter {

    private Context mContext;
    public LayoutInflater inflater=null;
    public CustomAdapter(Context context, List<? extends Map<String, ?>> data, int resource, String[] from, int[] to) {
        super(context, data, resource, from, to);
        mContext = context;
        inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi=convertView;
        try{
            if(convertView==null)
                vi = inflater.inflate(R.layout.list_movie, null);
            HashMap<String, Object> data = (HashMap<String, Object>) getItem(position);
            TextView tvtitle = vi.findViewById(R.id.titleTextView);
            TextView tvduration = vi.findViewById(R.id.durationTextView);
            TextView tvgenre = vi.findViewById(R.id.genreTextView);

            ImageView imgmovie =vi.findViewById(R.id.movieImageView);

            String dtitle = (String) data.get("title");//hilang
            String dduration =(String) data.get("duration");
            String dgenre =(String) data.get("genre");
            String dmid=(String) data.get("movieid");

            tvtitle.setText(dtitle);
            tvduration.setText(dduration);
            tvgenre.setText(dgenre);

            String image_url = "http://funsproject.com/fahriProject/imageUpload/movieCover/"+dmid+".jpg";
            Picasso.get().load(image_url).fit().into(imgmovie);

        }catch (IndexOutOfBoundsException e){

        }

        return vi;
    }
}
